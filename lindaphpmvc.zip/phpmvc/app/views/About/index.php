<div class="container">
    <h1 class="mt-4">Item Details</h1>
    <p>Fresh Vegetable Start From Rp.2000</p>
    <img src="<?= BASEURL; ?>/img/Brokoli.jpeg" width="200" class="rounded-circle">
    <img src="<?= BASEURL; ?>/img/Kentang.jpeg" width="200" class="rounded-circle">
    <img src="<?= BASEURL; ?>/img/pokcoy.jpeg" width="200" class="rounded-circle">


</div>
<div class="container">
    <h1 class="mt-4"></h1>
    <p></p>
    <img src="<?= BASEURL; ?>/img/Paprika.jpeg" width="200" class="rounded-circle">
    <img src="<?= BASEURL; ?>/img/Wortel.jpeg" width="200" class="rounded-circle">
    <img src="<?= BASEURL; ?>/img/Bawangmerah.jpeg" width="200" class="rounded-circle">


</div>