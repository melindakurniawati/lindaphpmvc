<?php

define('BASEURL', 'http://localhost/phpmvc/public');