<?php

require_once 'core/app.php';
require_once 'core/controller.php';
require_once 'core/database.php';
require_once 'core/flasher.php';

require_once 'config/config.php';